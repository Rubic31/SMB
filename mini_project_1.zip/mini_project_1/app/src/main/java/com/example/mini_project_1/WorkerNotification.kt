package com.example.mini_project_1

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.*

class WorkerNotification(private val context: Context, workerParams: WorkerParameters) :
    Worker(context, workerParams) {

    override fun doWork(): Result {
        Log.d("WORKER INITIATED", "WORKER INITIATED")
        showNotification()
        return Result.success()
    }

    private fun showNotification() {

        val productName = inputData.getString("FIRST_KEY")


        createChannel(context)

        val notiIntent = Intent().also {
            it.component = ComponentName(
                "com.example.mini_project_1", "com.example.mini_project_1.ProductListActivity"
            )
        }


        val pendingIntent = PendingIntent.getActivity(
            context, 1, notiIntent, PendingIntent.FLAG_IMMUTABLE
        )

        val notification =
            NotificationCompat.Builder(context, "channel1").setContentTitle("Dodano produkt")
                .setContentText(productName).setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentIntent(pendingIntent).setAutoCancel(true).build()


        NotificationManagerCompat.from(context).notify(createID(), notification)
    }

    fun createChannel(context: Context) {
        val notiChannel = NotificationChannel(
            "channel1", "Product Add Channel", NotificationManager.IMPORTANCE_DEFAULT
        )
        NotificationManagerCompat.from(context).createNotificationChannel(notiChannel)
    }


    fun createID(): Int {
        val now = Date()
        return SimpleDateFormat("ddHHmmss", Locale.US).format(now).toInt()
    }
}