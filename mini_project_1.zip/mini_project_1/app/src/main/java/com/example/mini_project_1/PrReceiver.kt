package com.example.mini_project_1


import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkRequest


class PrReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.d("BROADCAST RECEIVED", "BROADCAST RECEIVED")

        val notificationWorkRequest: WorkRequest = OneTimeWorkRequestBuilder<WorkerNotification>()
            .setInputData(createInputData(intent))
            .build()

        WorkManager
            .getInstance(context)
            .enqueue(notificationWorkRequest)

    }


    fun createInputData(intent: Intent): Data {
        return Data.Builder()
            .putString("FIRST_KEY", intent.getStringExtra("productName"))
            .build()
    }
}